import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import lti.pojo.Order;
import lti.util.HibernateUtil;

public class TestOrder {
	@Test
	public void testCaseOrder() {
		Session session= HibernateUtil.getSession();
		
		//Transaction tx= session.getTransaction();
		Transaction tx= session.beginTransaction();
		
		
		Order or = new Order();
		or.setId(123);
		or.setOrderDate(new Date());
		or.setAmount(10000);
		or.setPromoCode("HC1023");
		
		
		session.save(or);
		tx.commit();
	}
}
